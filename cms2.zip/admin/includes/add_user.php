

  <?php
        
        if(!isset($_SESSION['username'])){
            
            header("Location:../index.php");
        }
        ?>

<?php

if(isset($_POST['add_user'])) {
    
                               
                                $user_first_name = $_POST['first_name'];
                                $user_lastname = $_POST['last_name'];
                                $user_role = $_POST['user_role'];
      $user_email = $_POST['user_email'];
      $user_password = $_POST['user_password'];
      $username = $_POST['username'];
                    /*            $post_image = $_FILES['image']['name'];
                                $post_image_temp = $_FILES['image']['tmp_name'];
                                $post_tags = $_POST['post_tags'];
                                $post_content = $_POST['post_content'];
                                $post_date = date('d-m-y');
                              
    
    move_uploaded_file($post_image_temp, "../images/$post_image"); 
                                */
    

    
    
    $sql = "INSERT INTO users(user_firstname,user_lastname,user_role,username,user_email,password) VALUES('{$user_first_name}','{$user_lastname}','{$user_role}','{$username}','{$user_email}','{$user_password}')";
    
    $create_user_query = mysqli_query($connection,$sql);
    
    confirmQuery($create_user_query);
      
echo "User Created:".""."<a href='users.php'>View Users</a>";                          
}

?>



<form action="" method="post" enctype="multipart/form-data">

    <div class="form-group">
    <label for="title">First Name</label>
    <input type="text" class="form-control" name="first_name">
    </div>
    <div class="form-group">
    <label for="title">Last Name</label>
    <input type="text" class="form-control" name="last_name">
    </div>
    <label for="title">User Role</label><br>
    <select class="form-control" name="user_role">
    <option value="subuscriber">
    Select Option
    </option><option value="admin">
    Admin
    </option><option value="subuscriber">
    Subuscriber
    </option>
    
    </select>
<br><br>
    
    
  <!--  
    <div class="form-group">
    <label for="title">User image</label>
    <input type="file" class="form-control" name="image">
    </div> 

-->
    <div class="form-group">
    <label for="title">USERNAME</label>
    <input type="text" class="form-control" name="username">
    </div>

    <div class="form-group">
    <label for="title">Password</label>
    <input type="text" class="form-control" name="user_password">
    </div>

    
    
    <div class="form-group">
    <label for="title">E-MAIL</label>
    <input type="text" class="form-control" name="user_email">
    </div>

    
    <div class="form-group">
        <input type="submit" class="btn btn-primary" name="add_user" value="ADD">
    </div>



</form>