
  <?php
        
        if(!isset($_SESSION['username'])){
            
            header("Location:../index.php");
        }
        ?>


<?php

if(isset($_GET['edit_user'])) {
    
   $the_user_id = $_GET['edit_user'];

    
              
                    $query = "SELECT * FROM users WHERE user_id = $the_user_id";
                    $select_users = mysqli_query($connection,$query);
                                
                                
                            while($row = mysqli_fetch_assoc($select_users)){
                        
                                 $user_id = $row['user_id'];
                                $username = $row['username'];
                                $user_password = $row['password'];
                                $user_firstname = $row['user_firstname'];
                                $user_lastname = $row['user_lastname'];
                                $user_user_image = $row['user_image'];
                                $user_role = $row['user_role'];
                                $user_email = $row['user_email'];
                            }
    
    
}


if(isset($_POST['edit_user'])) {
    
         
                                $user_first_name = $_POST['first_name'];
                                $user_lastname = $_POST['last_name'];
                                $user_role = $_POST['user_role'];
      $user_email = $_POST['user_email'];
      $user_password = $_POST['user_password'];
      $username = $_POST['username'];
                    /*            $post_image = $_FILES['image']['name'];
                                $post_image_temp = $_FILES['image']['tmp_name'];
                                $post_tags = $_POST['post_tags'];
                                $post_content = $_POST['post_content'];
                                $post_date = date('d-m-y');
                              
    
    move_uploaded_file($post_image_temp, "../images/$post_image"); 
                                */



    
     
                        $query = "UPDATE users SET user_firstname = '{$user_first_name}',user_lastname= '{$user_lastname}',user_role = '{$user_role}',username = '{$username}',password = '{$user_password}',user_email = '{$user_email}' WHERE user_id = $the_user_id";

    
     $update_user = mysqli_query($connection,$query);
    confirmQuery($update_user);

header("location:users.php?source=edit_user&edit_user='{$the_user_id}'");

    
  
                                
}




?>



<form action="" method="post" enctype="multipart/form-data">

    <div class="form-group">
    <label for="title">First Name</label>
    <input type="text" value="<?php echo $user_firstname ;?>" class="form-control" name="first_name">
    </div>
    <div class="form-group">
    <label for="title">Last Name</label>
    <input type="text" value="<?php echo $user_lastname ;?>" class="form-control" name="last_name">
    </div>
    <label for="title">User Role</label><br>
    <select class="form-control" name="user_role">
    <option value="subuscriber"><?php echo $user_role; ?></option>
    <?php
    
    if($user_role == 'admin'){
    
     
    echo "<option value='subuscriber'>
    subuscriber
    </option>";
    } else {
echo "<option value='admin'>
  admin
    </option>";


}
 
       ?>
  
    
    </select>
<br><br>
    
    
  <!--  
    <div class="form-group">
    <label for="title">User image</label>
    <input type="file" class="form-control" name="image">
    </div> 

-->
    <div class="form-group">
    <label for="title">USERNAME</label>
    <input type="text" value="<?php echo $username ;?>" class="form-control" name="username">
    </div>

    <div class="form-group">
    <label for="title">Password</label>
    <input type="password" value="<?php echo $user_password ;?>" class="form-control" name="user_password">
    </div>

    
    
    <div class="form-group">
    <label for="title">E-MAIL</label>
    <input type="text" value="<?php echo $user_email ;?>" class="form-control" name="user_email">
    </div>

    
    <div class="form-group">
        <input type="submit" class="btn btn-primary" name="edit_user" value="Edit">
    </div>



</form>