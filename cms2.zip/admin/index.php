<!--<script src="tinymce/tinymce.min.js"></script>-->
    <?php include"includes/header.php"; ?>

    <div id="wrapper">

  <?php include"includes/navigation.php"; 
        
        if(!isset($_SESSION['username'])){
            
            header("Location:../index.php");
        }
        ?>
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                        Welcome to admin
                            <small><?php echo $_SESSION['username'];?></small>
                        </h1>
                   
                        
                        
                    </div>
                </div>
                <!-- /.row -->

           
             <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-comments fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                   
                                   <?php
                                    
                                    $query = "SELECT * FROM posts";
                                    $select_all_post = mysqli_query($connection,$query);
                                    $post_counts = mysqli_num_rows($select_all_post);
                                    
                                    
                                    echo "<div class='huge'>{$post_counts}</div>";                                    
                                    ?>
                                   
                                   
                                    
                                    <div>Posts</div>
                                </div>
                            </div>
                        </div>
                        <a href="./posts.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-comment fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                   
                                   <?php
                                    
                                    $query = "SELECT * FROM comments";
                                    $select_all_com = mysqli_query($connection,$query);
                                    $com_counts = mysqli_num_rows($select_all_com);
                                    
                                    
                                    echo "<div class='huge'>";
                                    echo $com_counts;
                                    echo "</div>";
                                    
                                    ?>
                                    <div>Comments</div>
                                </div>
                            </div>
                        </div>
                        <a href="comments.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-user fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <?php
                                    
                                    $query = "SELECT * FROM users";
                                    $select_all_users = mysqli_query($connection,$query);
                                    $user_counts = mysqli_num_rows($select_all_users);
                                    
                                    
                                    echo "<div class='huge'>";
                                    echo $user_counts;
                                    echo "</div>";
                                    
                                    ?>
                                    
                                    <div>Users</div>
                                </div>
                            </div>
                        </div>
                        <a href="users.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-th-list fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                     <?php
                                    
                                    $query = "SELECT * FROM categories";
                                    $select_all_cat = mysqli_query($connection,$query);
                                    $cat_counts = mysqli_num_rows($select_all_cat);
                                    
                                    
                                    echo "<div class='huge'>";
                                    echo $cat_counts;
                                    echo "</div>";
                                    
                                    ?>
                                    
                                    <div>Categories</div>
                                </div>
                            </div>
                        </div>
                        <a href="categories.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <!-- /.row -->
           
           <div class="row">
               
            
                 
               
               
           </div>
           
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
<?php include"includes/footer.php";?>