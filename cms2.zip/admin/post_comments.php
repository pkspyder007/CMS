
<?php include"includes/header.php"; ?>

    <div id="wrapper">

  <?php include"includes/navigation.php"; ?>
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                        Welcome to admin
                            <small>Author</small>
                        </h1>
<table class="table table-bordered table-hover">
                            
                         <thead>
                            <tr>
                             
                             <td>ID</td>
                                <td>Author</td>
                                <td>Comments</td>
                                <td>E-mail</td>
                                <td>Status</td>
                                <td>In Response To</td>
                                <td>Date</td>
                                <td>Approve</td>
                                <td>Unapprove</td>
                                <td>Delete</td>
                              
                                
                                
                                                          </tr>
                            
                            </thead>
                            
                        <tbody>
                            
                            <?php
                            
                            
                             $id = mysqli_real_escape_string($connection,$_GET['id']);
                    
                    $query = "SELECT * FROM comments WHERE comment_post_id = $id";
                         
                    $select_comments = mysqli_query($connection,$query);
                                
                                
                            while($row = mysqli_fetch_assoc($select_comments)){
                        
                                 $comment_id = $row['comment_id'];
                                $comment_post_id = $row['comment_post_id'];
                                $comment_author = $row['comment_author'];
                                $comment_email = $row['comment_email'];
                                $comment_status = $row['comment_status'];
                                $comment_content = $row['comment_content'];
                                $comment_date = $row['comment_date'];
                                  //$post_content = $row['post_content'];
                                
                                
                                echo "<tr>";
                                echo "<td> $comment_id </td>";
                                echo "<td> $comment_author </td>";
                                echo "<td> $comment_content </td>";
                                echo "<td> $comment_email </td>";
                                     
                                
                                
                                echo "<td> $comment_status </td>";
                                
                                $query = "SELECT * FROM posts WHERE post_id = $comment_post_id";
                                $select_post_id_query = mysqli_query($connection,$query);
                               $row = mysqli_fetch_assoc($select_post_id_query);
                                    
                                    $post_id = $row['post_id'];
                                    $post_title = $row['post_title'];
                                      echo "<td> <a href='../post.php?p_id=$post_id'>$post_title</a> </td>";
                                    
                               
                                
                              
                              

                                
                                echo "<td> $comment_date </td>";
                                echo "<td> <a href='post_comments.php?approve=$comment_id&&id={$id}'>Approve</a> </td>";
                                echo "<td> <a href='post_comments.php?unapprove=$comment_id&&id={$id}'>Unapprove</a> </td>";
                                
                                  echo "<td> <a href='post_comments.php?delete=$comment_id&&id={$id}'>Delete</a> </td>";
                               
                               
                               
                                echo "</tr>";
                            }
                            
                            
                            ?>
                            
                                
                           
                              
                                
                           
                            </tbody>  
                            
                        
                        
                        
                        </table>

<?php




if(isset($_GET['approve'])) {
$id = $_GET['id'];
    $the_comment_id = $_GET['approve'];
    
    $query = "UPDATE comments SET comment_status = 'Approved' WHERE comment_id = $the_comment_id";
    $approve_query = mysqli_query($connection,$query);
    header("location:post_comments.php?id={$id}");
    
}


if(isset($_GET['unapprove'])) {
    $id = $_GET['id'];
    $the_comment_id = $_GET['unapprove'];
    
    $query = "UPDATE comments SET comment_status = 'Unapproved' WHERE comment_id = $the_comment_id";
    $unapprove_query = mysqli_query($connection,$query);
    
    header("location:post_comments.php?id=$id");
    
}



if(isset($_GET['delete'])) {
    $id = $_GET['id'];
    $the_comment_id = $_GET['delete'];
    
    $query = "DELETE FROM comments WHERE comment_id = {$the_comment_id}";
    $delete_query = mysqli_query($connection,$query);
    header("location:post_comments.php?id=$id");
    
}

?>


             
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
<?php include"includes/footer.php";?>